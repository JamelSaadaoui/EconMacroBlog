###############################################################################
#
# Author: Matthew Gordon on behalf of Todd Clark
# Email: tclarkresearch@gmail.com
#
# Last Updated: 1/12/2024
#
# File Name: QREN_TSCV_Grid_Search
#            """ Quantile Regression - Elastic Net - Time Series Cross-
#             Validation Grid Search """
#
# Project:
#    Specification Choices in Quantile Regression for Macroeconomic Forecasting
#  
# Performs a grid search for each value of lambda from the 'hqreg' function
# from the 'hqreg' package. The grid search works by using time series cross
# validation as outlined by Hart (1994), but uses the formulation for quantile
# regression as outlined by Bayer (2018). Slight modification is made to the
# Bayer formula in order to account for different forecasting steps, h. Searches
# to find the lambda that minimizes CV_t and returns it.
#
# Changes it so that lambdas can be fed in from a model and where we take
# advantage of pathwise optimization and estimate all these lambdas in a single
# path
#
###############################################################################

# Loads relevant package.
library(hqreg)

# Defines the main function that performs the TSCV procedure. 
# Inputs are:
#
#   X_training - The design matrix. This is all the X data that is 
#                available up to t0-1.
#
#   Y_training - The response matrix. This is the Y data that is available up
#                up t0-1
#
#   Alpha - The elastic net mixing parameter. Treated as given for an 
#            application.
#
#   Tau - The quantile to be estimated. Treated as given for an application.
#
#   Min_training_index - The matrix row index of the last entry to use as the 
#                        initial training observations for the model. This 
#                        corresponds to the tau used in the TSCV procedure in
#                        Bayer 2018
#
#  t0 - The forecasting jump-off period used. The TSCV will occur on all
#       observations between min_training_index and t0-1+h
#
#  h - The forecasting h jumpoff for the forecasting period. This function will
#      select a lambda through a grid search that minimizes the TSCV loss for 
#      a given h.
#
# lambda_sequence - a sequence of lambdas to feed into the model
                 
qren_tscv_find_lambda = function(X_training,Y_training, alpha, tau, 
                                 min_training_index, t0, h, lambda_sequence = NULL){
  
  # If no sequence is provided than produce it based on training data
  if(is.null(lambda_sequence)){
    # Using all available data, create a base model that will provide the sequence
    # of lambdas to search over.
    base_model = hqreg(X_training,Y_training, method = "quantile", 
                           tau = tau, alpha = alpha)
    
    # Extract the sequence of lambdas
    lambda_sequence = base_model$lambda
  }
  
  # Create an accumulator matrix to store our results
  rhos_matrix = NULL

  # Loop over each time period
  for(t in min_training_index:(t0-1-h)){
    
    # Create a base model to get a sequence of lambdas that fit
    # restricted pseudo-realtime data in the cross evaluation
    base_model = hqreg(X_training[1:t,],Y_training[1:t,], method = "quantile", 
                               tau = tau, alpha = alpha)
    
    # Combine the lambdas of the base model with our cross-validation lambdas.
    # This step is to ensure that the lambdas are "close enough" to each other
    # for the pathwise optimization. (EXPLAIN FURTHER)
    updated_lambdas = unique(rev(sort(c(lambda_sequence, base_model$lambda))))
    updated_model <- update(base_model, lambda=updated_lambdas)
    
    # Perform the t plus h forecast using the cross validation
    # lambdas
    forecast_t_plus_h = predict(updated_model, X_training[t+h,], 
                                type="response", lambda=lambda_sequence)
    
    # Define U, the same as in Bayer 2018, as the real Y_training at t+h minus
    # the forecasted value. That is, the forecast error
    u = Y_training[t+h,] - forecast_t_plus_h
    
    # This conditional serves as the indicator function used in Bayer 2018.
    indicator = ifelse(u<=0, 1, 0)
    
    # Define rho as being the quantile, minus the indicator, times u
    rho = (tau - indicator) * u
    
    # Store the rho
    rhos_matrix = rbind(rhos_matrix, rho)
    
  }
  # Create CV_t by summing over the rhos, per lambda, and dividing by scalar
  CV_matrix = apply(rhos_matrix, 2, sum) / ((t0-1) - min_training_index)
  
  # Format CV_matrix with the given lambda
  # on the left column and the TSCV loss on the right column
  CV_matrix = cbind(lambda_sequence, as.vector(CV_matrix))
  
  # Find the minimum TSCV loss out of all the lambdas
  minimum_CV = min(CV_matrix[,2])
  
  # Find the row index that correspondes with this minimized TSCV loss
  minimizing_lambda_index = which(CV_matrix == minimum_CV, arr.ind = T)
  
  # Find the lambda associated with the minimum TSCV loss
  minimizing_lambda = CV_matrix[minimizing_lambda_index[1], 1]
  
  # Return this lambda
  return(minimizing_lambda)
}
