#!/bin/bash
#SBATCH --job-name=QR_Forecasts  # create a short name for your job
#SBATCH -N 1                     # number of nodes
#SBATCH -n 32                    # total number of cores
#SBATCH --mem=256g               # total memory in gb
#SBATCH --time=5-00:00:00        # total run time limit (D-HH:MM:SS)
#SBATCH --mail-type=all          # send email on job start, end and fault
#SBATCH --mail-user=matthew.gordon@clev.frb.org
#SBATCH --array 1-2112

# load the r/4.2.2 module
module load gcc r/4.2.2
# print the modules loaded (for debugging purposes)
module list
# print the hostname this job is running on (for debugging purposes)
hostname
# run your R program
Rscript QR_Forecasts_Array.R $SLURM_ARRAY_TASK_ID