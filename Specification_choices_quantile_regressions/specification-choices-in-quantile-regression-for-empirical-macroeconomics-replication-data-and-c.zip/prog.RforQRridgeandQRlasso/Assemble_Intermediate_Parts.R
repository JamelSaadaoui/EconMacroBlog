# Assemble Forecasts
use_packages = function(package_vector){
  for(pkg in package_vector){
    if(!require(pkg, character.only = TRUE)){
      install.packages(pkg, character.only = TRUE)
      library(pkg, character.only = TRUE)
    }else{
      library(pkg, character.only = TRUE)
    }
  }
}
use_packages(c("readr", "openxlsx"))

applications = c("infl", "unemp", "GDPsmall", "GDPlarge", "GDPvlarge", 
                 "G7GDP_AUS", "G7GDP_DEU", "G7GDP_FRA", "G7GDP_GBR", 
                 "G7GDP_JPN", "G7GDP_USA", "headinflchg")
mixtures     = c("ridge", "lasso")
windows      = c("recursive", "rolling")
horizons     = c(1, 2, 4, 12)
quantiles    = c(0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95)

tasks = expand.grid(applications, mixtures, windows, horizons, quantiles)
colnames(tasks) = c("data_application", "mixture_alpha", "window_type", "forecast_horizon", "quantile_tau")

for(data_application in applications){
  for(regression_type in mixtures){
    for(window_type in windows){
      
      gathered_horizon = list()
      for(forecast_horizon in horizons){
        
        gathered_tau = NULL
        for(quantile_tau in quantiles){
          
          intermediate_name = paste0("Intermediate_Parts/forecast_", data_application, "_", regression_type, "_", window_type,"_h", forecast_horizon, "_Tau",quantile_tau*100, ".csv")
          intermediate_file = read_csv(intermediate_name, show_col_types = FALSE, name_repair = "unique_quiet")
          intermediate_file = intermediate_file[, 2:ncol(intermediate_file)] # Cuts away useless csv column
          
          if(is.null(gathered_tau)){
            gathered_tau = intermediate_file
          } else{
            gathered_tau = merge(gathered_tau, intermediate_file, by="t0", all.x=TRUE)
          }
        }
        
        gathered_horizon[[paste0("h=", forecast_horizon)]] = gathered_tau
        
      }
      
      export_name = paste0("Forecasts/forecast_", data_application, "_", regression_type, "_", window_type, ".xlsx")
      write.xlsx(gathered_horizon, export_name, overwrite = TRUE)
      
    }
  }
}
