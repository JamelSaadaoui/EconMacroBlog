###############################################################################
#
# Author: Matthew Gordon on behalf of Todd Clark
# Email: tclarkresearch@gmail.com
#
# Last Updated: 1/11/2024
#
# File Name: QR_Forecasts_Array.R
#            """ Quantile Regression - Forecasts for use on SLURM Array """
#
# Project:
#    Specification Choices in Quantile Regression for Macroeconomic Forecasting
#  
# This provides code for a pseudo out-of-sample forecasting exercise from 
# 1985:Q1 to 2021:Q2 / 2023:Q3 using a quantile regression with both ridge and
# lasso.
#
# The data for this file is provided in the "Data" folder
#
# Specifically, this code uses the hqreg package to forecast different
# macroeconomic variables. Currently, this code supports inflation, unemployment
# GDPsmall, GDPlarge, and GDPvlarge. Forecasting periods are for h=1, 2, 4, 12 
# and quantiles are:
# (0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95)
#
# For ridge regresion, the elastic-net mxiture parameter is alpha=0 while for
# LASSO it is alpha=1.
#
# This script uses a time series cross-validation grid search upon 100 lambda
# candidates, following Bayer (2018), in order to find the ideal regularization
# parameter for the quantile regression. Due to the computational expense of 
# running this project, parallel processing through nested foreach loops from 
# the 'foreach' and 'doParallel' packages are used to calculate each quantile
# at each h on a different core (that is user-specificed).
#
# This code treats data recursively both in forecasts and cross-validation.
#
# Note that this code estimates forecasts recursively
#
# Code is assumed to receive a taskid from 1:max(nrow(tasks)) for a SLURM
# array
###############################################################################

# SLURM Array Set-up ------------------------------------------------------
applications = c("infl", "unemp", "GDPsmall", "GDPlarge", "GDPvlarge", 
                 "G7GDP_AUS", "G7GDP_DEU", "G7GDP_FRA", "G7GDP_GBR", 
                 "G7GDP_JPN", "G7GDP_USA", "headinflchg")
mixtures     = c(0, 1)
windows      = c("recursive", "rolling")
horizons     = c(1, 2, 4, 12)
quantiles    = c(0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95)

tasks = expand.grid(applications, mixtures, windows, horizons, quantiles)
colnames(tasks) = c("data_application", "mixture_alpha", "window_type", "forecast_horizon", "quantile_tau")
taskid <- Sys.getenv('SLURM_ARRAY_TASK_ID')
task = tasks[taskid, ]

# Specification Parameters ------------------------------------------------

# Parallel Options
run_parallel     = TRUE                  # Whether to run the code parallel
num_workers      = "detectCores()"       # Number of parallel workers to use. Only used if run_parallel = TRUE

# Application Options
data_application = task$data_application # What data application to perform: infl, unemp, GDPsmall, GDPlarge, GDPvlarge, G7GDP_AUS, G7GDP_DEU, G7GDP_FRA, G7GDP_GBR, G7GDP_JPN, G7GDP_USA
mixture_alpha    = task$mixture_alpha    # Elastic-net mixing parameter of values [0, 1]. Alpha = 1 is lasso and Alpha = 0 is ridge
window_type      = task$window_type      # Currently only support recursive window_type
forecast_horizon = task$forecast_horizon # Forecast horizon h. Currently supports h=1, 2, 4, and 12
quantile_tau     = task$quantile_tau     # Quantile to estimate at. Paper uses 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95

# Initialize --------------------------------------------------------------
# Loads up the necessary packages

# Defines helper function to easily load and download required packages
use_packages = function(package_vector){
  for(pkg in package_vector){
    if(!require(pkg, character.only = TRUE)){
      install.packages(pkg, character.only = TRUE)
      library(pkg, character.only = TRUE)
    }else{
      library(pkg, character.only = TRUE)
    }
  }
}

# Load / Install Packages
use_packages(c("quantreg", "hqreg", "foreach", "doParallel", "readr"))

# Define packages for use in foreach
packages = c("quantreg", "hqreg") # Packages to use in foreach

# Imports a function to employ time series cross validation and a grid search.
source("QR_TSCV_Grid_Search_v2.R")

# Create specified number of workers
# When parallel computing, it is considered good practice to monitor your CPU
# temperature and adjust your number of workers if it is too high.
if(run_parallel){
  # Set a list of the packages that will be used in the foreach loop.
  # Create Workers
  num_workers = detectCores() # Detect how many core your have available. 
  registerDoParallel(num_workers) 
}

# Defines a label for this regression type
if(mixture_alpha == 1){
  regression_type = "lasso"
} else if(mixture_alpha==0){
  regression_type = "ridge"
} else{
  regression_type = paste0("ElasticNet-", mixture_alpha)
}


# Load Data ---------------------------------------------------------------
data_filename = paste0("Data/dataforR_", data_application, "_h", forecast_horizon, ".csv")
data = read_csv(data_filename)

# Find the index that corresponds to 1985:Q1
initial_t0 = which(data[, 1]=="1985:01")

# Defines the minimum training size used in the first train / test split.
# Set so that the first train set is on 10 years of data (40 observations).
# However, if the test set is less than 20 observations we adjust the test
# set so there are observations (5 years of data). If this adjustment brings
# our minimum training size below some chosen absolute minimum, 15 here,
# then set our minimum training size to this absolute minimum. If this absolute
# minimum cannot even give us a single testing observation then we do not have
# enough data.
min_training_index = 40                                           # Try for 10 years of training data
if((initial_t0-1)-min_training_index < 20){                       # Check if this gives 10 years of testing data
  min_training_index = (initial_t0-1) - 20                        # If not, give 10 years of testing data
  if(min_training_index < 15){                                    # Check if this forces our training data below 15 observation, our absolute minimum desired training size
    min_training_index = 15                                       # If so, try for 15 observations of data
    if((initial_t0-1)-min_training_index-forecast_horizon < 0){   # Check if this even gives us even one test observation
      stop("Not enough data for test/train split")                # If it does not, throw error
    }
  }
}


# Check if file already produced ------------------------------------------
# Makes it easy to just re-run an entire array and only do incomplete jobs
check_name = paste0("Intermediate_Parts/forecast_", data_application, "_", regression_type, "_", window_type,"_h", forecast_horizon, "_Tau",quantile_tau*100, ".csv")
if(file.exists(check_name)){
  print(paste("File already ran:", check_name))
  stop("File already ran! Please delete file if you want to re-run it.")
}


# Forecasts ---------------------------------------------------------------

# Start code timing
code_time_start = proc.time()

# Construct the design and response matrices along with a date matrix
X = as.matrix(sapply(data[, 4:ncol(data)], as.numeric))
Y = as.matrix(sapply(data[, 2], as.numeric))
dates = as.matrix(data[,1])
h = forecast_horizon

# Begin forecasting exercise
# Start with t0=1985:Q1.  Use y,x data starting with the first available 
# observation and ending with t0-1=1984:Q4 to estimate a quantile regression
# using data from the first available through t0-1=1984:Q4. Form an h-step
# ahead forecast using X(,t0-1+h) * beta and the ideal lambda from the grid 
# search. The grid search minimizes the TSCV error for the given data and 
# forecasting h. Put a date of t0 on the forecast
# then move forward one quarter to t0=1985:Q2.  Use y,x data starting with 
# the first available observation and ending with t0-1, estimate, and 
# forecast.  Continue forward to obtain the time series of h-step 
# ahead forecasts.
# Maximum forecasting data possible, according to this specification, is 
# number of X's - h + 1, for a given h.
forecasts = foreach(t0 = initial_t0:(nrow(X)-h+1), .packages = packages, .combine=rbind) %dopar% {
  
  # Switch data based on window type
  if(window_type == "recursive"){
    # Create X, Y matrix using all data available up to but not including
    # t0
    Y_training = as.matrix(Y[1:(t0-1),])
    X_training = as.matrix(X[1:(t0-1),])
    
    # Cross-validate on all available data
    Y_TSCV     = as.matrix(Y[1:t0-1,])
    X_TSCV     = as.matrix(X[1:t0-1,])
    
  }else if(window_type == "rolling"){
    # Create X, Y matrix using a window size based on the initial forecast size
    Y_training = as.matrix(Y[(t0-(initial_t0-1)):(t0-1),])
    X_training = as.matrix(X[(t0-(initial_t0-1)):(t0-1),])
    
    # Cross-validate on all available data
    Y_TSCV     = as.matrix(Y[1:(t0-1),])
    X_TSCV     = as.matrix(X[1:(t0-1),])
  }
  
  # Create a model based on this data with solutions paths dependent on 
  # lambda
  model = hqreg(X_training, Y_training, method = "quantile", 
                    tau = quantile_tau, alpha = mixture_alpha)
  
  # Find the ideal lambda using TSCV
  lambda = qren_tscv_find_lambda(X_training=X_TSCV, Y_training=Y_TSCV,
                                 alpha=mixture_alpha,
                                 tau = quantile_tau, min_training_index,
                                 t0, h, model$lambda)
  
  # Using the 'ideal' lambda, predict using t0-1+h data for X upon the
  # model. While the predict.hqreg model does provide exact=TRUE as an
  # option, this is not needed as the model in qren_tscv_find_lambda will
  # search over the exact same lambdas as 'model'
  # Bind these forecasts, column-wise, to the date.
  Y_forecast = cbind(dates[t0,], 
                     predict(model, X[t0-1+h,], type="response", lambda=lambda))
}

# Display code run time
run_time = proc.time() - code_time_start
print(paste("Code took", run_time[3], "seconds"))


# Export ------------------------------------------------------------------

# Organize data into dataframe for exporting
export_dataframe = as.data.frame(forecasts)
colnames(export_dataframe) = c("t0", quantile_tau)
export_dataframe[,2] = as.numeric(export_dataframe[,2])

# Define export file name
export_name = paste0("Intermediate_Parts/forecast_", data_application, "_", regression_type, "_", window_type,"_h", forecast_horizon, "_Tau",quantile_tau*100, ".csv")

# Export file
write.csv(export_dataframe, export_name)

# Close Cluster
if(run_parallel){
  stopImplicitCluster()
}