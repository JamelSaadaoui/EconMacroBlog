**********************************************************************************************
Sanctions and the Exchange Rate in Time
by Barry Eichengreen; Massimo Ferrari Minesso; Arnaud Mehl; Isabel Vansteenkiste; Roger Vicquéry

Replication package (10 October 2023)
**********************************************************************************************


**********************************************************************************************
A. Stylized facts
**********************************************************************************************
The code \ReplicationFacts\STYLIZED FACTS (SEPTEMBER 2023).do replicates the following charts:
Figure 1, Figure 2, Figure 3 as well as Figures A.1 to Figure A.7.

Make sure you have changed the directory (i.e. adjust the command line cd "to your own path") 
before running the code!


**********************************************************************************************
B. Regression results
**********************************************************************************************
The code \ReplicationRegressions\ReplicationFile.do replicates the following charts and tables:
Figure A.9, Figure 4, Figure 5, Figures A.10 to A.29 and Tables B.2 and B.3.

Make sure you have changed the directory (i.e. adjust the command line cd "to your own path") 
before running the code!

For Tables B.2 and B.3 all regression results are stored in TableOutput.xls; the paper 
reports regression outputs for the 1-week and 4-week horizons. 

Tables B.4 and B.5 are based on the estimate results obtained for Figure 5, Figure A.25 and 
Figure A.26 discusssed above. 


**********************************************************************************************
C. Figures A.8 & A.29
**********************************************************************************************

Data on historical FX volatility are reported in Figure A8.xlsx available in the folder 
ReplicationFacts. The worksheetsheet "Output" contains the underlying data. 

Data for Figure A.29 can be found in Figure A20.xlsx available in the folder ReplicationFacts. 
The figure is based on the output of the UIP regressions discussed in the paper. The episodes
considered are listed in the second worksheet.